﻿using MelonLoader;

[assembly: MelonInfo(typeof(PMAPI.EntryPoint), "PMAPI", "1.0.0", "Seva167")]
[assembly: MelonGame("PrimitierDev", "Primitier")]
[assembly: MelonColor(255, 255, 255, 0)]
[assembly: MelonPlatformDomain(MelonPlatformDomainAttribute.CompatibleDomains.IL2CPP)]
